#include<bits/stdc++.h>
#include"Match.h"
#include"T_20.h"
using std::endl;
using std::cout;

namespace example{
     void T20_Match::set_Max_Over(){
          maxover=20;
      }
      int T20_Match::Get_Max_Over(){
          return maxover;
      }
}