#include<bits/stdc++.h>
#include"Match.h"
#include"T_10.h"
using std::endl;
using std::cout;

namespace example{
     void T10_Match::set_Max_Over(){
          maxover=10;
      }
      int T10_Match::Get_Max_Over(){
          return maxover;
      }
}